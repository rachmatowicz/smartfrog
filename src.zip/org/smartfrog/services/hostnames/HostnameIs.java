package org.smartfrog.services.hostnames;

import org.smartfrog.sfcore.workflow.conditional.Condition;

/**
 *
 */
public interface HostnameIs extends Condition {
    String ATTR_HOSTNAMES = "hostnames";
}
