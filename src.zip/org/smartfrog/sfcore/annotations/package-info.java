package org.smartfrog.sfcore.annotations;

/**
 * This package contains annotations for use within the SmartFrog framework
 */